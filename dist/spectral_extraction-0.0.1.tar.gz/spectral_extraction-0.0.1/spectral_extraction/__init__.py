"""
spectral_extraction.

LITTLE CODE TO EXTRACT 1D ESPECTRA FROM 2D.
"""

__version__ = "0.0.1"
__author__ = 'Felipe Avila'
__credits__ = 'UV'